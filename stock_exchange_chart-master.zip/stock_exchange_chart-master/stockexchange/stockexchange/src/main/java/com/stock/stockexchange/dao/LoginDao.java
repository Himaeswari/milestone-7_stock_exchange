package com.stock.stockexchange.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stock.stockexchange.model.User;

@Repository
public interface LoginDao extends JpaRepository<User,Integer>{

	
	@Query("Select u from User u where u.userId =:user and u.password = :password and u.userType = 'user' ")
	User validateUser(@Param("user") int user , @Param("password") String password);
	
	@Query("Select u from User u where u.userId =:user and u.password = :password and u.userType = 'admin' ")
	User validateAdmin(@Param("user") int user , @Param("password") String password);

}
