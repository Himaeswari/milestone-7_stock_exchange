package com.stock.stockexchange.service;

import java.util.List;
import com.stock.stockexchange.model.Stock;

public interface StockService {

	public Stock insertStock(Stock stock) throws Exception;
	 public List<Stock> getStockList() throws Exception;
	public Stock getStockById(int id) throws Exception;
	public void deleteStockById(int id);
	
	
}
