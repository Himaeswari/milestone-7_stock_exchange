package com.stock.stockexchange.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.stock.stockexchange.model.Sector;
import com.stock.stockexchange.model.StockPrice;

public interface StockPriceDao extends JpaRepository<StockPrice,Integer> {
	
	@Query(value ="Select sum(current_price) from stock_price where company_id in (select company_code from company where sector_id= :id)",nativeQuery=true)
	float findStockPrice(@Param("id") int id);

	
	@Query("Select s From StockPrice s where s.companyCode=:companyCode and s.date between :startdate and :enddate")
    public List<StockPrice> findBydate(@Param("companyCode") int companyCode,@Param("startdate") Date startdate,@Param("enddate") Date enddate);

	
    @Query("select s.currentPrice from StockPrice s where s.companyCode=:companyCode and s.date between :startDate and :endDate")
   public List<Double> findByCompanyCode(@Param(value="companyCode") Integer companyCode,@Param(value = "startDate") Date startDate, @Param(value = "endDate") Date endDate);

}
