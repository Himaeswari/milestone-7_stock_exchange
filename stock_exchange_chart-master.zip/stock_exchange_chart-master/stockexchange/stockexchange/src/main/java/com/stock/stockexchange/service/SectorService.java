package com.stock.stockexchange.service;

import java.util.List;
import com.stock.stockexchange.model.Sector;

public interface SectorService {

	List<Sector> fetchSector() throws Exception;
}
