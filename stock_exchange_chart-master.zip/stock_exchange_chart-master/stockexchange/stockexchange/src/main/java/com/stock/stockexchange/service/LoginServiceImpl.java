package com.stock.stockexchange.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.stockexchange.dao.LoginDao;
import com.stock.stockexchange.model.User;

@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
	LoginDao loginDao;
	
	@Override
	public User validateUser(int user, String password) throws Exception
	{
		
		
	  User check=loginDao.validateUser(user,password);
	  System.out.println("hi "+check);
	  return check;
	}
	
	@Override
	public User insertUser(User user) throws Exception {
		user.setUserType("user");
		user.setConfirmed("yes");
	    loginDao.save(user);
		return null;
	}
}
