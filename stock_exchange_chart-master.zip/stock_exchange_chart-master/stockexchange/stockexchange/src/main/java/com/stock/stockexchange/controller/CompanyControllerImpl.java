package com.stock.stockexchange.controller;


import java.util.List;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.stock.stockexchange.model.Company;
import com.stock.stockexchange.model.Sector;
import com.stock.stockexchange.service.CompanyService;
import com.stock.stockexchange.service.SectorService;



@Controller
public class CompanyControllerImpl {

	
	@Autowired
	private CompanyService companyService;
	
	
	@Autowired
	private SectorService sectorService;
	
	@RequestMapping(path="/companyList")
	public ModelAndView getCompanyList() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("companyList");
		try
		{
		mv.addObject("companyList",companyService.getCompanyList());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return mv;
	}
	
	
	@RequestMapping(value = "/addCompany", method = RequestMethod.GET)
	public String getCompanyForm(ModelMap model){
		System.out.println("add company");
		Company company=new Company();
		List<Sector> sectorList=null;
		try
		{
		sectorList = sectorService.fetchSector();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		model.addAttribute("sectorList",sectorList);
		model.addAttribute("company", company);
		return "companyForm";
	}
	
	@RequestMapping(value = "/addCompany", method = RequestMethod.POST)
	public String formHandler(@Valid @ModelAttribute("company") Company company,BindingResult result, 
			 Model model)
	{
		System.out.println(company);
		if(result.hasErrors())
		{
		    System.out.println("error");
			model.addAttribute("company",company);
			return "companyForm";
		}
		try
		{
		companyService.insertCompany(company);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	    return "CompanyView";
	}
	
	@RequestMapping(path="/update")
	public ModelAndView edit(@RequestParam("companyCode") int id, ModelMap model) 
	{
		
		List<Sector> sectorList=null;
		ModelAndView mav=null;
	
			try
			{
			Company company = companyService.getCompanyById(id);
			try
			{
			sectorList = sectorService.fetchSector();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			 
			model.addAttribute("sectorList",sectorList);
			model.addAttribute("company", company);
		    }
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		
		mav=new ModelAndView("companyEdit");
		
		return mav;
	}

   
	
	@RequestMapping(value="/updatesave")
	public String editsave(@ModelAttribute("company") Company company)
	{
		
			try
			{
		     companyService.insertCompany(company);
			}
		
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		return "redirect:/companyList";
	}


}

