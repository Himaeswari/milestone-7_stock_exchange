package com.stock.stockexchange.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.stock.stockexchange.dao.IpoDao;
import com.stock.stockexchange.model.IpoPlanned;

@RequestMapping("/api")
@RestController
public class IpoController {
	
	@Autowired
	IpoDao ipoDao;
	@GetMapping("/getIpoByCompany/{cname}")
	public List<IpoPlanned> getAllCustomers(@PathVariable("cname") String cname) {
		

		List<IpoPlanned> ipo = new ArrayList<>();
		try
		{
		ipo=ipoDao.findByIpoByCompanyName(cname);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return ipo;
	}

	  @PostMapping("/saveIpo")
	    public void saveIpo(@RequestBody IpoPlanned ipoPlanned){
		  try
		  {
		  ipoDao.save(ipoPlanned);
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
		  }
	       
	    }
	  
	  @GetMapping("/deleteIpo/{id}")
	     public String deleteIpo(@PathVariable("id") int id)
	     {
		  try
		  {
		  ipoDao.deleteById(id);
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
		  }
		  return "Ipo Deleted Successfully";
	     }


}
