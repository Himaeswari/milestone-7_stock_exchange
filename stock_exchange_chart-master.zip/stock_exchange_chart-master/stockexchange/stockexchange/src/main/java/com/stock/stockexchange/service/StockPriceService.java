package com.stock.stockexchange.service;

import java.util.Date;
import java.util.List;

import com.stock.stockexchange.model.StockPrice;

public interface StockPriceService {

	List<StockPrice> findBydate(int companyCode, Date startdate, Date enddate) throws Exception;

	float findStockPrice(int id) throws Exception;

	List<Double> findByCompanyCode(int companyCode, Date date1, Date date2) throws Exception;

}
