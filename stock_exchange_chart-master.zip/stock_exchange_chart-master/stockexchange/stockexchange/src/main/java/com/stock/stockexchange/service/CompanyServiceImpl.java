package com.stock.stockexchange.service;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.stock.stockexchange.dao.CompanyDao;
import com.stock.stockexchange.model.Company;
import com.stock.stockexchange.model.Sector;
import com.stock.stockexchange.model.User;


@Service
public class CompanyServiceImpl implements CompanyService {

	@Autowired
	private CompanyDao companyDao;
	
	@Override
	public Company insertCompany(Company company) throws Exception {
	    companyDao.save(company);
	  
		return null;
	}
	

	@Override
	public List<Company> findCompanyBySector(int id) throws Exception{
		
		return companyDao.findCompanyBySector(id);
	}


	@Override
	public List<Company> getCompanyList() throws Exception{
		return companyDao.findAll();
	}
	
	
	@Override
	public List<Company> findMatchingCompany(String name) throws Exception{
		
		return companyDao.findMatchningCompany(name);
	}


	@Override
	public Company getCompanyById(int id) throws Exception{
		return companyDao.getCompanyById(id);
	}


}

